﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Outils.TConsole
{
	class Program
	{
		static void Main(string[] args)
		{
            TestApp app = TestApp.Instance;
			app.Title = "Northwind2";

			// Ajout des pages
			Page accueil = new PageAccueil();
			app.AddPage(accueil);
			

			// Affichage de la page d'accueil
			app.NavigateTo(accueil);

			app.Run();
		}
	}
}
